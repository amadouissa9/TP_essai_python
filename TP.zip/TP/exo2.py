age = int(input("quel age avez vous ?" ,))
if age==0:
    print("impossible d avoir age negatif")
elif age>=18:
    print("vous ete Majeur")
else:
    print("nous etes munieur") 