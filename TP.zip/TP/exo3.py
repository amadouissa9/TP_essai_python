for i in range(1,10):
    print("le " ,i, " nombre est :" ,i)
    n = 1
    while n <= 5:
        cr = n*2
        print("le carre ", n , "est " ,cr)
        n += 1