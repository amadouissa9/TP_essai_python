jourSemaine=["lundi,mardi,mercredi,jeudi,vendredi,samedi,dimanche"]
for i in jourSemaine:
    print(i)
    mois_anne=("janvier","fevrier","mars","avril", "mai","juin","juillet","aout","octobre","novembre","decembre")
    i = 0
    while i < len (mois_anne[i]):
        print(mois_anne)
        i+=1