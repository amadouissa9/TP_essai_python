print("bonjour")
nom = "amadou"
print("je m appel est :" , nom)